import qrcode
import PySimpleGUI as sg

sg.theme('purple')

# Define valid QR code colors
qr_colors = ['black', 'white', 'red', 'blue', 'green', 'yellow', 'cyan', 'magenta']

# To define the layout of the GUI
layout = [[sg.Text('To generate QR code, ENTER TEXT:')],
          [sg.InputText()],
          [sg.Text('Select QR code fill color:')],
          [sg.OptionMenu(qr_colors, default_value='black', key='fill_color')],
          [sg.Text('Select QR code background color:')],
          [sg.OptionMenu(qr_colors, default_value='white', key='back_color')],
          [sg.Button('Create QR code'), sg.Button('Exit')]]

# Creating the GUI window
window = sg.Window('QR Code Generator', layout)

# Create event loop
while True:
    event, values = window.read()
    if event == sg.WIN_CLOSED or event == 'Exit':
        break
    elif event == 'Create QR code':

        # Get the text from the input box
        text = values[0]
        if text.strip():

            # Get the selected fill and background colors
            fill_color = values['fill_color']
            back_color = values['back_color']

            # Generate the QR code with the selected colors
            qr = qrcode.QRCode(version=1, box_size=10, border=5)
            qr.add_data(text)
            qr.make(fit=True)
            img = qr.make_image(fill_color=fill_color, back_color=back_color)

            # Save the generated QR code image to a file
            img_file = 'qr_code.png'
            img.save(img_file)

            # Display a popup message with the generated QR code image
            sg.popup('QR code generated!', image=img_file)

            window.close()
        else:
            # Show an error message if the input text is empty
            sg.popup_error('Please enter some text')
